
public class Vector {
	Position start;
	Position end;
	
	
	public Vector(Position start, Position end) {
		super();
		this.start = start;
		this.end = end;
	}

	public Vector() {
		super();
		this.start = new Position();
		this.end = new Position();
	}
	
	public Position getStart() {
		return start;
	}

	public void setStart(Position start) {
		this.start = start;
	}

	public Position getEnd() {
		return end;
	}

	public void setEnd(Position end) {
		this.end = end;
	}
	
	
	public double getMagnitude() {
		return start.getDistance(end);
	}
	public double getDirection() {
		return start.getAngle(end);
	}
	

}
