import javax.swing.*;
import java.awt.*;

public class SimulationPanel extends JPanel {
	private static final long serialVersionUID = 1L;
	private Fabric fabric; 

	public static final int NODE_SIZE = 10;
	
	public SimulationPanel() {
        setFocusable(true);
        setBackground(Color.WHITE);
        setPreferredSize(new Dimension(600, 600));
        
    	fabric = new Fabric(100,100,20,20,20, 100);
    	
    	// set the upper corners to be not movable.
    	fabric.getNodes()[0][0].setMovable(false);
    	fabric.getNodes()[0][fabric.getWidth()-1].setMovable(false);
    	fabric.getNodes()[0][(int)(fabric.getWidth()-1)/2].setMovable(false);

    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        Node[][] nodes =fabric.getNodes();
        for(int i=0; i < fabric.getHeight(); i++) {
	        for(int j=0; j < fabric.getWidth(); j++) {
	        	Node curN = nodes[i][j];
	        	g2d.drawOval((int)curN.getP().getX()-NODE_SIZE/2, (int)curN.getP().getY()-NODE_SIZE/2, NODE_SIZE, NODE_SIZE);
	        	if(j>0) {
	        		Node prevN = nodes[i][j-1];
	        		g2d.drawLine((int)curN.getP().getX(), (int)curN.getP().getY(), (int)prevN.getP().getX(), (int)prevN.getP().getY());
	        	}
	        	if(i>0) {
	        		Node prevN = nodes[i-1][j];
	        		g2d.drawLine((int)curN.getP().getX(), (int)curN.getP().getY(), (int)prevN.getP().getX(), (int)prevN.getP().getY());
	        	}   
	        }
        }
    }
    
    
    public void update(double dt) {
    	Vector gravity = new Vector(0,9.81);
    	Vector springForce;
    	Node[][] nodes =fabric.getNodes();
        Node curN;
        double dumpingCF = 0.3;
        
        //while(true) {
        	for(int i=0; i < fabric.getHeight(); i++) {
    	        for(int j=0; j < fabric.getWidth(); j++) {
    	        	curN = nodes[i][j];
    	        	
    	        	// Applying gravity.
    	        	curN.applyForce(gravity, dt);
    	        	
    	        	// Calculating and applying spring forces.
    	        	if(i<fabric.getHeight()-1) {
    	        		springForce = calculateSpringForce(curN,nodes[i+1][j]);
    	        		curN.applyForce(springForce, dt);
    	        		nodes[i+1][j].applyForce(Vector.neg(springForce), dt);
    	        	}
    	        	if(j<fabric.getWidth()-1) {
    	        		springForce = calculateSpringForce(curN,nodes[i][j+1]);
    	        		curN.applyForce(springForce, dt);
    	        		nodes[i][j+1].applyForce(Vector.neg(springForce), dt);
    	        	}
    	        	
    	        	// Calculating and applying damping.
    	        	double vMag=curN.getVelocity().getMag();
    	        	double vDir=curN.getVelocity().getDir();
    	        	double dampingMag = -dumpingCF*vMag;
    	        	double dampingDir = vDir+ Math.PI;
    	       
    	        	Vector dampingVector = new Vector();
    	        	dampingVector.set(dampingDir, vMag);
    	        	
    	        	curN.applyForce(dampingVector, dt);
    	        
    	        }
            }
            //repaint();
        //}
    }
    
    // F=−k⋅Δx
    public Vector calculateSpringForce(Node a, Node b) {
    	double distance = a.getP().getDistance(b.getP());
    	// Calculate magnitude of spring force using Hooke's Law
        double restLength = fabric.getSpacing(); // Rest length of the spring
        double displacement = distance - restLength; // Displacement from rest length
        double magnitude = fabric.getStiffness() * displacement; // Hooke's Law
        
        // Calculate the direction of the force vector
    	double direction = a.getP().getAngle(b.getP());
    	
    	Vector F = new Vector();
    	F.set(direction, magnitude);
    	
    	return F;
    }
}
