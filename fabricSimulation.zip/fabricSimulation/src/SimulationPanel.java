import javax.swing.*;
import java.awt.*;

public class SimulationPanel extends JPanel {
	private static final long serialVersionUID = 1L;
	private Fabric fabric; 

	public static final int NODE_SIZE = 10;
	
	public SimulationPanel() {
        setFocusable(true);
        setBackground(Color.WHITE);
        setPreferredSize(new Dimension(600, 600));
        
    	fabric = new Fabric();
    	fabric.getNodes().add(new Node(new Position(300,300)));
    	fabric.getNodes().add(new Node(new Position(350,300)));

    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        for(int i=0; i<fabric.getNodes().size();i++) {
        	Node curN = fabric.getNodes().get(i);
        	g2d.drawOval((int)curN.getP().getX()-NODE_SIZE/2, (int)curN.getP().getY()-NODE_SIZE/2, NODE_SIZE, NODE_SIZE);

        	if(i>0) {
        		Node prevN = fabric.getNodes().get(i-1);
        		g2d.drawLine((int)curN.getP().getX(), (int)curN.getP().getY(), (int)prevN.getP().getX(), (int)prevN.getP().getY());
        	}
        	
        }
    }
    
    
    public void update() {
    	
        repaint();
    }
    
}
