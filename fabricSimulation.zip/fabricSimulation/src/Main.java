import java.time.Duration;
import java.time.Instant;
import javax.swing.JFrame;

public class Main {
    private static final double FIXED_TIME_STEP = 0.016; // Fixed time step (in seconds)

    public static void main(String[] args) {
        SimulationPanel simulation = new SimulationPanel();
        JFrame frame = new JFrame("Fabric Simulation");
        frame.add(simulation);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        Instant previousTime = Instant.now();
        long targetFPS = 60;
        long nsPerFrame = 1_000_000_000 / targetFPS;

        int frames = 0;
        long timer = System.currentTimeMillis();

        while (true) {
            Instant currentTime = Instant.now();
            double deltaTime = Duration.between(previousTime, currentTime).toNanos() / 1_000_000_000.0;
            previousTime = currentTime;

            // Update simulation with fixed time step
            while (deltaTime >= FIXED_TIME_STEP) {
                simulation.update(FIXED_TIME_STEP);
                deltaTime -= FIXED_TIME_STEP;
            }
            
            simulation.repaint();

            frames++;

            if (System.currentTimeMillis() - timer > 1000) {
                //System.out.println("FPS: " + frames);
                frames = 0;
                timer += 1000;
            }

            long frameTime = Duration.between(previousTime, Instant.now()).toNanos();
            long sleepTime = nsPerFrame - frameTime;
            sleepTime = Math.max(0, sleepTime);

            try {
                Thread.sleep(sleepTime / 1_000_000, (int) (sleepTime % 1_000_000));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
