import javax.swing.JFrame;

public class Main {

	public static void main(String[] args) {
		SimulationPanel simulation = new SimulationPanel();
		JFrame frame = new JFrame("Fabric Simulation");
        frame.add(simulation);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        
        simulation.update();
	}

}
