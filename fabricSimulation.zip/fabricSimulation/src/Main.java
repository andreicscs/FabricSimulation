import javax.swing.JFrame;
public class Main {

    public static void main(String[] args) {
        SimulationPanel simulation = new SimulationPanel();
        JFrame frame = new JFrame("Fabric Simulation");
        frame.add(simulation);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        // Variables for tracking time
        long lastTime = System.nanoTime();
        long targetFPS = 60;
        long nsPerFrame = 1_000_000_000 / targetFPS;

        // Variables for calculating FPS
        int frames = 0;
        long timer = System.currentTimeMillis();

        while (true) {
            long now = System.nanoTime();
            long delta = now - lastTime;
            lastTime = now;

            simulation.update(delta / 1_000_000_000.0); // Convert nanoseconds to seconds for delta time

            // Repaint the simulation panel
            simulation.repaint();

            frames++; // Increment the frames counter

            // If one second has passed, print the FPS and reset the counter
            if (System.currentTimeMillis() - timer > 1000) {
                System.out.println("FPS: " + frames);
                frames = 0;
                timer += 1000;
            }

            long sleepTime = Math.max(0, nsPerFrame - delta); // Ensure sleepTime is non-negative
            //System.out.println("sleeptime: " + sleepTime);

            try {
                Thread.sleep(sleepTime / 1_000_000, (int) (sleepTime % 1_000_000)); // Convert nanoseconds to milliseconds
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
