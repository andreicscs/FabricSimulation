
import javax.swing.JFrame;

public class Main {
    private static final int TARGET_FPS = 60;
    private static final long OPTIMAL_TIME = 1_000_000_000 / TARGET_FPS; // nanoseconds per frame

    public static void main(String[] args) {
        SimulationPanel simulation = new SimulationPanel();
        JFrame frame = new JFrame("Fabric Simulation");
        frame.add(simulation);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        long previousTime = System.nanoTime();

        int frames = 0;
        long timer = System.currentTimeMillis();

        while (true) {
            long currentTime = System.nanoTime();
            double deltaTime = (currentTime - previousTime) / 1_000_000_000.0;
            previousTime = currentTime;

            simulation.update(deltaTime); // dt in seconds
            simulation.repaint();

            frames++;

            long frameTime = System.nanoTime() - currentTime;
            if (frameTime < OPTIMAL_TIME) {
                try {
                    Thread.sleep((OPTIMAL_TIME - frameTime) / 1_000_000); // Sleep to maintain frame rate
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            if (System.currentTimeMillis() - timer > 1000) {
                System.out.println("FPS: " + frames);
                System.out.println("DT: " + deltaTime);
                frames = 0;
                timer += 1000;
            }
        }
    }
}
