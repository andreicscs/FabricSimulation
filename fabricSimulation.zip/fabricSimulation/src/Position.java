
public class Position {
	double x;
	double y;
	
	public Position(double x, double y) {
		super();
		this.x = x;
		this.y = y;
	}
	
	public Position() {
		super();
		this.x = 0;
		this.y = 0;
	}

	public double getX() {
		return x;
	}
	public double getY() {
		return y;
	}
	public void setX(double x) {
		this.x = x;
	}
	public void setY(double y) {
		this.y = y;
	}
	public double getDistance(Position p) {
		double result= 0.0f;
		double xDistance = Math.abs(this.getX()-p.getX());
		double yDistance = Math.abs(this.getY()-p.getY());
		result = Math.abs(xDistance-yDistance);
		return result;
	}
	public double getAngle(Position p) {
		double result= 0.0f;
		double xDistance = this.getX()-p.getX();
		double yDistance = this.getY()-p.getY();
		result = xDistance/yDistance;
		return result;
	}
}
