
public class Node {
	Position p;
	Vector velocity;
	Vector acceleration;
	
	public Node(Position p) {
		super();
		this.p = p;
		this.velocity = new Vector();
		this.acceleration = new Vector();
	}
	
	public Position getP() {
		return p;
	}

	public void setP(Position p) {
		this.p = p;
	}

	public Vector getVelocity() {
		return velocity;
	}
	public Vector setVelocity(Vector velocity) {
		return this.velocity = velocity;
	}
	public Vector getAcceleration() {
		return acceleration;
	}
	public void setAcceleration(Vector acceleration) {
		this.acceleration = acceleration;
	}
	
}
