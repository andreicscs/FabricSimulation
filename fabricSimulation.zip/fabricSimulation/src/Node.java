
public class Node {
	private Position p;
	private Vector velocity;
	private Vector acceleration;
	private double mass;
	private Boolean movable;
	private Boolean curMovable;
	private Boolean linked;

	public Node(Position p) {
		super();
		this.p = p;
		this.velocity = new Vector();
		this.acceleration = new Vector();
		this.movable = true;
		this.curMovable = this.movable;
		this.mass=1;
		this.linked = true;
	}
	public Node() {
		super();
		this.p = new Position();
		this.velocity = new Vector();
		this.acceleration = new Vector();
		this.movable = true;
		this.curMovable = this.movable;
		this.mass=0.3;
		this.linked = true;
	}
	
	public Position getP() {
		return p;
	}

	public void setP(Position p) {
		this.p = p;
	}

	public Vector getVelocity() {
		return velocity;
	}
	public Vector setVelocity(Vector velocity) {
		return this.velocity = velocity;
	}
	public Vector getAcceleration() {
		return acceleration;
	}
	public void setAcceleration(Vector acceleration) {
		this.acceleration = acceleration;
	}

	public Boolean getMovable() {
		return movable;
	}

	public void setMovable(Boolean movable) {
		this.movable = movable;
	}
	
	public double getMass() {
		return mass;
	}

	public void setMass(double mass) {
		this.mass = mass;
	}

	// Euler Integration
	public void applyForce(Vector force, double dt){
		if (!this.movable || !this.curMovable) {
            return;
        }

        // F = ma => a = F / m
        Vector forceDivMass = Vector.div(force, this.mass);
        this.acceleration.add(forceDivMass);

        // v = v + a * dt
        Vector scaledAcceleration = Vector.mult(this.acceleration, dt);
        this.velocity.add(scaledAcceleration);

        // p = p + v * dt
        Vector scaledVelocity = Vector.mult(this.velocity, dt);
    
	    this.getP().setX(this.getP().getX() + scaledVelocity.getX());
	    this.getP().setY(this.getP().getY() + scaledVelocity.getY());

	    // Reset acceleration after each frame
	    this.acceleration.mult(0); 
	}

	public Boolean getLinked() {
		return linked;
	}

	public void setLinked(Boolean linked) {
		this.linked = linked;
	}

	public Boolean getCurMovable() {
		return curMovable;
	}

	public void setCurMovable(Boolean curMovable) {
		this.curMovable = curMovable;
	}


}
