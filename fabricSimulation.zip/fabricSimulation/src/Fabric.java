import java.util.ArrayList;

public class Fabric {
	ArrayList<Node> nodes;

	public Fabric(ArrayList<Node> nodes) {
		super();
		this.nodes = nodes;
	}

	public Fabric() {
		super();
		this.nodes = new ArrayList<Node>();
	}
	
	public ArrayList<Node> getNodes() {
		return nodes;
	}

	public void setNodes(ArrayList<Node> nodes) {
		this.nodes = nodes;
	}
}
